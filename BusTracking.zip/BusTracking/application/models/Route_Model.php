<?php
defined ( 'BASEPATH' ) or exit ( 'No direct script access allowed' );
class Route_Model extends CI_Model {
	public function __construct() {
		parent::__construct();
        $this->load->database();
	}

    
    

    public function get_bus_route_details()
    {


        //get all availble route records from bt_bus_route_master database.
        $this->db->select('*');
		$query = $this->db->get('bt_bus_route_master');
		return $query->result();

    }
  
	

}