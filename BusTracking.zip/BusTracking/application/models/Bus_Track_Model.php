<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Bus_Track_Model extends CI_Model
{
    public function __construct()
    {
        parent::__construct();
        $this->load->database();

    }

    public function Track_Bus_Location($bus_trip_id, $bus_trip_start_date_time, $bus_route_id, $bus_id, $bus_driver_id, $bus_conductor_id, $bus_trip_status, $bus_available_seats, $bus_last_known_geo_location_time, $bus_last_known_location_latitude, $bus_last_known_location_longitude, $bus_eta_end_location)
    {

        $response_array = array();
        $date = date('Y/m/d H:i:s');

        $record_flag = $this->Is_Bus_Route_Recored_Present($bus_route_id);

        if ($record_flag == -1) {
            //new bus route entry for the bus.
            //insert new recored.

            $bus_details = array(
                'bus_trip_id' => $bus_trip_id,
                'bus_trip_start_date_time' => $date,
                'bus_route_id' => $bus_route_id,
                'bus_id' => $bus_id,
                'bus_driver_id' => $bus_driver_id,
                'bus_conductor_id' => $bus_conductor_id,
                'bus_trip_status' => $bus_trip_status,
                'bus_available_seats' => $bus_available_seats,
                'bus_last_known_geo_location_time' => $date,
                'bus_last_known_location_latitude' => $bus_last_known_location_latitude,
                'bus_last_known_location_longitude' => $bus_last_known_location_longitude,
                'bus_eta_end_location' => $bus_eta_end_location,

            );

            $this->db->insert('bt_bus_trip_details', $bus_details);
        } else {

            //existing bus route  entery update the data.

            $data = array('bus_last_known_geo_location_time' => $date, 'bus_last_known_location_latitude' => $bus_last_known_location_latitude, 'bus_last_known_location_longitude' => $bus_last_known_location_longitude);
            $this->db->where('bus_route_id', $bus_route_id);
            $this->db->update('bt_bus_trip_details', $data);
        }

        $response_array[] = $bus_trip_id;
        $response_array[] = 1;
        return $response_array;
    }

    //########################################### FOR CHECK BUS ROUTE RECORED PRESENT OR NOT ###################################################################

    public function Is_Bus_Route_Recored_Present($bus_route_id)
    {

        $this->db->select('*');
        $this->db->from('bt_bus_trip_details');
        $this->db->where('bus_route_id', $bus_route_id);

        $bus_route_status_result = $this->db->get();
        $number_of_rows = $bus_route_status_result->num_rows();
        if ($number_of_rows == 0) {
            $record_flag = -1;
        } else {
            $record_flag = 1;
        }
        return $record_flag;

    } //end of Is_Bus_Route_Recored_Present function.
    //#################################END OF Is_Bus_Route_Recored_Present function ######################################################################

    /*
    @* @param bus_id Description
    this function takes the bus is as parameter
    and return the total seat bus capacity.
     */

    public function get_bus_seat_capacity_count($bus_id)
    {

        $this->db->select('*');
        $this->db->from('bt_bus_master');
        $this->db->where('bus_id ', $bus_id);
        $bus_seat_capacity_status_result = $this->db->get();
        $result_object = $bus_seat_capacity_status_result->result();
        $number_of_rows_registration_status = $bus_seat_capacity_status_result->num_rows();

        $bus_seat_capacity = $result_object[0]->bus_seat_capacity;

        return $bus_seat_capacity;

    } //end of get_bus_seat_capacity_count function

    /**
     * @* @param string $jsonArraySelectedSeats this the comma sepreated user selected list.
     * @* @param int $no_of_seats  the no of selected seats by user.
     * @* @param int $bus_route_id bus route id for which seat updation is done.
     *
     *
     * this fucntion takes the above parameter and update/insert the details in the
     * bt_bus_trip_details table.
     *
     */
    public function update_seat_details($jsonArraySelectedSeats, $no_of_seats, $bus_route_id)
    {

        $response_array = array();
        $date = date('Y/m/d H:i:s');
        $seats_seleted = '';

        $record_flag = $this->Is_Bus_Route_Recored_Present($bus_route_id);

        $booked_seats = $this->get_booked_seat_count($bus_route_id);

        $no_of_seats += $booked_seats;

        for ($i = 0; $i < sizeof($jsonArraySelectedSeats); $i++) {

            $seats_seleted .= "" . $jsonArraySelectedSeats[$i] . ",";
        }

        if ($record_flag == -1) {
            //new bus route entry for the bus.
            //insert new recored.

            $bus_details = array(
                'bus_trip_id' => '',
                'bus_trip_start_date_time' => $date,
                'bus_route_id' => $bus_route_id,
                'bus_id' => '',
                'bus_driver_id' => '',
                'bus_conductor_id' => '',
                'bus_trip_status' => '',
                'bus_available_seats' => $no_of_seats,
                'bus_seat_availability' => $seats_seleted,
                'bus_last_known_geo_location_time' => $date,
                'bus_last_known_location_latitude' => '',
                'bus_last_known_location_longitude' => '',
                'bus_eta_end_location' => '',

            );

            $this->db->insert('bt_bus_trip_details', $bus_details);
        } else {

            //existing bus route  entery update the data.

            $data = array('bus_seat_availability ' => $seats_seleted, 'bus_available_seats' => $no_of_seats);
            $this->db->where('bus_route_id', $bus_route_id);
            $this->db->update('bt_bus_trip_details', $data);
        }

        $response_array[] = $bus_route_id;
        $response_array[] = 1;

        return $response_array;

    }

    /**
     * @* @param int $bus_route_id bus unique route number.
     *
     * This function takes the bus route no as parameter
     * and return the no of seats currently booked for the bus.
     */
    public function get_booked_seat_count($bus_route_id)
    {

        $this->db->select("*");
        $this->db->from('bt_bus_trip_details');
        $this->db->where('bus_route_id = ', $bus_route_id, false);
        $Seat_Availability_details = $this->db->get();
        $Seat_Availability_details_result = $Seat_Availability_details->result();

        $bus_booked_seats = $Seat_Availability_details_result[0]->bus_available_seats;

    }

    /**
     *
     * @* @param int $bus_trip_id bus unique route number
     *
     * This function takes the bus route no as parameter
     * and return the no of seats currently booked and currently booked seats numbers for the bus.
     */
    public function Get_Bus_Seat_Availability($bus_trip_id)
    {

        $response_array = array();
        $return_array = array();

        $this->db->select("*");
        $this->db->from('bt_bus_trip_details');
        $this->db->where('bus_route_id = ', $bus_trip_id, false);
        $Seat_Availability_details = $this->db->get();
        $Seat_Availability_details_result = $Seat_Availability_details->result();

        $bus_seat_availability = $Seat_Availability_details_result[0]->bus_seat_availability;
        $bus_available_seats = $Seat_Availability_details_result[0]->bus_available_seats;

        $seat_detail_array = explode(",", $bus_seat_availability);

        $return_array[] = array('total_booked_seats' => $bus_available_seats, 'booked_seat_nos' => $seat_detail_array);

        return $return_array;
    }

}
