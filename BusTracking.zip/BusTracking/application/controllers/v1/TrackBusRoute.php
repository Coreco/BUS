<?php

defined('BASEPATH') OR exit('No direct script access allowed');

// This can be removed if you use __autoload() in config.php OR use Modular Extensions
/** @noinspection PhpIncludeInspection */
require APPPATH . 'libraries/REST_Controller.php';

/**
 * This is an example of a few basic user interaction methods you could use
 * all done with a hardcoded array
 *
 * @package         CodeIgniter
 * @subpackage      Rest Server
 * @category        Controller
 * @author          Phil Sturgeon, Chris Kacerguis
 * @license         MIT
 * @link            https://github.com/chriskacerguis/codeigniter-restserver
 */
class TrackBusRoute extends REST_Controller {

    function __construct()
    {
        // Construct the parent class
        parent::__construct();
        
       // error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));
        $this->load->model('Bus_Track_Model');
    }
    public function index_post()
    {


		
		$response_array = array();
		$bus_trip_id = $_POST['bus_trip_id'];
		$bus_trip_start_date_time = $_POST['bus_trip_start_date_time'];
		$bus_route_id = $_POST['bus_route_id'];
		$bus_id = $_POST['bus_id'];
		$bus_driver_id = $_POST['bus_driver_id'];
		$bus_conductor_id =  $_POST['bus_conductor_id'];
		$bus_trip_status =  $_POST['bus_trip_status'];
		$bus_available_seats =  $_POST['bus_available_seats'];
	

		$bus_last_known_geo_location_time =  $_POST['bus_last_known_geo_location_time'];
		$bus_last_known_location_latitude =  $_POST['bus_last_known_location_latitude'];
		$bus_last_known_location_longitude =  $_POST['bus_last_known_location_longitude'];
		$bus_eta_end_location =  $_POST['bus_eta_end_location'];
		

		$response = $this->Bus_Track_Model->Track_Bus_Location($bus_trip_id,$bus_trip_start_date_time,$bus_route_id,$bus_id,$bus_driver_id,$bus_conductor_id,$bus_trip_status,$bus_available_seats,$bus_last_known_geo_location_time,$bus_last_known_location_latitude,$bus_last_known_location_longitude,$bus_eta_end_location);
		
		$response_array['response_code'] = 	$response[1];
		$response_array['bus_trip_id'] = 	$response[0];
		print_r(json_encode($response_array));
    }
    

}