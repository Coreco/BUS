<?php

defined('BASEPATH') or exit('No direct script access allowed');

// This can be removed if you use __autoload() in config.php OR use Modular Extensions
/** @noinspection PhpIncludeInspection */
require APPPATH . 'libraries/REST_Controller.php';

/**
 * This is an example of a few basic user interaction methods you could use
 * all done with a hardcoded array
 *
 * @package         CodeIgniter
 * @subpackage      Rest Server
 * @category        Controller
 * @author          Phil Sturgeon, Chris Kacerguis
 * @license         MIT
 * @link            https://github.com/chriskacerguis/codeigniter-restserver
 */
class UpdateSeatDetails extends REST_Controller
{

    public function __construct()
    {
        // Construct the parent class
        parent::__construct();

        // error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));
        $this->load->model('Bus_Track_Model');
    }
    public function index_post()
    {


        $response_array = array();

        
        $selected_seats_json = $_POST ['selected_seats'];
        $no_of_seats = $_POST['no_of_seats'];
        $route_id = $_POST['route_id'];

        $jsonArraySelectedSeats = json_decode( $selected_seats_json,true);
        $response  = $this->Bus_Track_Model->update_seat_details($jsonArraySelectedSeats,$no_of_seats,$route_id);

        $response_array['response_code'] = 	$response[1];
		$response_array['route_id'] = 	$response[0];
		print_r(json_encode($response_array));



        

    }

}
