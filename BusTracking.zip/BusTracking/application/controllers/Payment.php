<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Payment extends CI_Controller{
	public function __construct()
	{
		parent::__construct();
		
	}
	public function index()
	{
	
		// calling payment rest api 
		// this rest api will return hash key
		
		// get payment parameters
		
		$key = $_POST['key'];
		$amount = $_POST['amount'];
		$txnid = $_POST['txnid'];
		$email = $_POST['email'];
		$productinfo = $_POST['productinfo'];
		$firstname = $_POST['firstname'];
		$udf1 = $_POST['udf1'];
		$udf2 = $_POST['udf2'];
		$udf3 = $_POST['udf3'];
		$udf4 = $_POST['udf4'];
		$udf5 = $_POST['udf5'];
		
		//$salt = uniqid(mt_rand(), true);
		//$salt = "pumnLaQSAg"; // Payutest
		//$salt = "Z2gLJQtPjV";  // Ekotro
		$salt = "7D2UJXc1c"; // Coreco
		
		$userAgent = $_SERVER['HTTP_USER_AGENT'];
	  	
		$service_url = 'https://corecotechnologies.com/CoOrganic/index.php/v1/Payment';
	  	
	  	$ch = curl_init($service_url);
	  	
		$curl_post_data = array(
	  			'key' => $key,
	  			'amount' =>$amount,
	  			'txnid' =>$txnid,
				'email' =>$email,
				'productinfo' =>$productinfo,
				'firstname' =>$firstname,
				'udf1' =>$udf1,
				'udf2' =>$udf2,
				'udf3' =>$udf3,
				'udf4' =>$udf4,
				'udf5' =>$udf5,
				'salt' =>$salt
				
	  	);
		
		//$data = http_build_query($curl_post_data);
	  	
	  	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	  	
	  	curl_setopt($ch, CURLOPT_POST, true);
	  	curl_setopt($ch, CURLOPT_USERAGENT, $userAgent);
	  	curl_setopt($ch, CURLOPT_POSTFIELDS, $curl_post_data);
	  	$curl_response = curl_exec($ch);
	
		print_r($curl_response);
	  	
	  	/*if ($curl_response === FALSE) {
	  		die("Curl failed: " . curL_error($ch));
	  	}
	  	else
	  	{
	  		
	  	}*/
		
	}
}	