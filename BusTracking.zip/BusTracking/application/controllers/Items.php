<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Items extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */

	public function __construct() {
		// Construct the parent class
		parent::__construct ();
		error_reporting ( E_ALL );
		ini_set ( "display_errors", 1 );
		$this->load->model ( 'Items_Model' );

	}
	
	
	public function index() {

		$message = $this->Items_Model->Get_All_Items();
		$Items_List_array = array('Items_List' =>$message);
		print_r(json_encode($Items_List_array));
	}
	
	public function get_item_price()
	{
		//echo "test";
		$message = $this->Items_Model->Get_Item_Price_List();
		$Items_Price_List_array = array('Items_Price_List' =>$message);
		print_r(json_encode($Items_Price_List_array));
	}
	 
	
}