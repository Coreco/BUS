<?php

$link = mysqli_connect("localhost", "crc_user", "Crc@1234", "CRC_Projects") or die('Unable to Connect');

$today = date("Y-m-d");

//echo "Date is : ".$today."<br>";
$t=date('d-m-Y');

echo date("l",strtotime($t)); // output: current day.
die();

// **************** CODE FOR GET COUNT OF ABSENT LUNCH BOX FOR TOADY *******************
$sql_query_for_nlb = "SELECT * FROM crc_emp_lunchbox_details where FIND_IN_SET('$today',`emp_nlb_dates`)";
$result_for_nlb = mysqli_query($link, $sql_query_for_nlb);
$num_of_rows_for_nlb = mysqli_num_rows($result_for_nlb);

//print_r($sql_query_for_nlb);

while($row = mysqli_fetch_assoc($result_for_nlb))
{
    $emp_mobile_number = $row['emp_mobile_number'];
    $company_id = $row['company_id'];
}



$sql_query_for_nlb_fast = "SELECT * FROM crc_emp_lunchbox_details where FIND_IN_SET('$today',`emp_fast_dates`)";
$result_for_nlb_fast = mysqli_query($link, $sql_query_for_nlb_fast);
$num_of_rows_for_nlb_fast = mysqli_num_rows($result_for_nlb_fast);




$sql_query_for_leave_dates = "SELECT * FROM crc_emp_lunchbox_details where FIND_IN_SET('$today',`emp_leave_dates`)";
$result_for_leave_dates = mysqli_query($link,$sql_query_for_leave_dates);
$num_of_rows_for_leave_dates = mysqli_num_rows($result_for_leave_dates);
while($row = mysqli_fetch_assoc($result_for_leave_dates))
{
    $emp_mobile_number = $row['emp_mobile_number'];
    $company_id = $row['company_id'];
    
    
    /***********************Get Leaves details***************************/
    	$sql_query_for_leave_details = "SELECT * FROM crc_emp_leave_details WHERE company_id=$company_id AND emp_mobile_number=$emp_mobile_number";
	$result_for_leave_details = mysqli_query($link,$sql_query_for_leave_details);
	$num_of_rows_for_leave_details = mysqli_num_rows($result_for_leave_details);
	$rows = mysqli_fetch_assoc($result_for_leave_details);
	$emp_leaves_availed_this_month = $rows['emp_leaves_availed_this_month'];
	$emp_leaves_availed_this_fin_year = $rows['emp_leaves_availed_this_fin_year'];
    	$emp_leaves_availed_this_month++;
    	$emp_leaves_availed_this_fin_year++;
    
    	$sql = "UPDATE crc_emp_leave_details SET emp_leaves_availed_this_month=$emp_leaves_availed_this_month, emp_leaves_availed_this_fin_year=$emp_leaves_availed_this_fin_year WHERE company_id=$company_id AND emp_mobile_number=$emp_mobile_number";

	if ($link->query($sql) === TRUE) {
	    echo "Record updated successfully";
	}
}

//die();
//get company configration details from the database.
$sql_query_for_get_daily_tiffen_count = "SELECT * FROM company_master";
$result_for_get_daily_tiffen_count = mysqli_query($link, $sql_query_for_get_daily_tiffen_count);
$num_of_rows_for_get_daily_tiffen_count = mysqli_num_rows($result_for_get_daily_tiffen_count);



while ($row = mysqli_fetch_assoc($result_for_get_daily_tiffen_count)) {
    $daily_tiffen_count = $row["company_lunch_box_count"];
    $comapany_id = $row["company_id"];
    $comapany_name = $row["company_name"];
    $company_contact_person_no = $row["company_contact_person_mobile"];
    $company_contact_person_name = $row["company_contact_person_name"];
    $company_email_id = $row["company_email_id"];
}




// print_r("C Name  :".$comapany_name."name :".$company_contact_person_name."no :".$company_contact_person_no."email :".$company_email_id."count : ".$daily_tiffen_count."id : ".$comapany_id);
// die();
//calculate the todays lunch box count.
$today_tiffen_count = $daily_tiffen_count - $num_of_rows_for_nlb - $num_of_rows_for_nlb_fast-$num_of_rows_for_leave_dates;



print_r($daily_tiffen_count."-".$num_of_rows_for_nlb."-".$num_of_rows_for_nlb_fast."-".$num_of_rows_for_leave_dates);
die();


$eggitrains = 0;
////////////////////////////////////// get currently active cateres number to send SMS ////////////////////////////////////////////
$sql_query_for_get_active_cateres_number = "SELECT * FROM `crc_caterer_master` WHERE `caterer_status`= 1 ";
$result_for_get_active_cateres_number = mysqli_query($link, $sql_query_for_get_active_cateres_number);

while ($row = mysqli_fetch_assoc($result_for_get_active_cateres_number)) {
    $caterers_mobile_number = $row["caterer_mobile_number"];
}

// echo " caterers_mobile_number :" . $caterers_mobile_number;
// die();

//add leading zeros to number.
$today_tiffen_count = str_pad($today_tiffen_count, 2, '0', STR_PAD_LEFT);
$num_of_rows_for_nlb_fast = str_pad($num_of_rows_for_nlb_fast, 2, '0', STR_PAD_LEFT);
$eggitrains = str_pad($eggitrains, 2, '0', STR_PAD_LEFT);

$message = "Lunchboxes @ CoReCo Technologies" . "
Date: " . $today . "
Veg: " . $today_tiffen_count . "
Fast: " . $num_of_rows_for_nlb_fast . "
Egg: " . $eggitrains . "
Contact- " . $company_contact_person_no;

// $message = "Lunchboxes @ CoReCo Technologies"."<br>"."
// Date: ".$today."<br>"."
// Veg: ".$today_tiffen_count."<br>"."
// Fast: ".$num_of_rows_for_nlb_fast."<br>"."
// Egg: ".$eggitrains."<br>"."
// Contact- ".$company_contact_person_no;




/************************ Email Template **********************/  
			
			
            $sql_query_to_get_email_template = "SELECT template_text FROM `co_lunchbox_email_template_master` WHERE `template_name` = 'lunchbox_template' ";
            $result_for_query_to_get_email_template = mysqli_query($link, $sql_query_to_get_email_template);
            while ($row = mysqli_fetch_assoc($result_for_query_to_get_email_template)) {
                $template_text = $row["template_text"];
            }
            



ini_set('SMTP','localhost');

$to = 'rahulnaik2894@gmail.com';
$subject = 'Lunchbox Details - @'.$today;


$template_text = str_replace("#~#full_name#~#",$comapany_name,$template_text);
$template_text = str_replace("#~#customer_phone#~#",$company_contact_person_no,$template_text);
$template_text = str_replace("#~#deliver_address1#~#",$today_tiffen_count,$template_text);
$template_text = str_replace("#~#deliver_address2#~#",$num_of_rows_for_nlb_fast,$template_text);
$template_text = str_replace("#~#deliver_address3#~#",$eggitrains,$template_text);



$body = $template_text;



///print_r($template_text);
//die();
$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
$headers .= 'From: CoReCo<info@corecotechnologies.com>' . "\r\n";
$headers.='X-Mailer: PHP/' . phpversion()."\r\n";
//$headers.='Bcc: info@corecotechnologies.com'."\r\n";


mail($to, $subject , $body,$headers);








   
/************************ Email Template **********************/  















/* make here curl call to send  sms to user
$resend_otp_flag = 0;
$system_name = "LunchBox";
$userAgent = $_SERVER['HTTP_USER_AGENT'];
$service_url = 'https://corecotechnologies.com/CRC_LunchBox/index.php/v1/SendSms';

$ch = curl_init($service_url);
$curl_post_data = array(
    'mobile_number' => $caterers_mobile_number,
    'message' => $message,
);

curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_USERAGENT, $userAgent);
curl_setopt($ch, CURLOPT_POSTFIELDS, $curl_post_data);
$curl_response = curl_exec($ch);
$json = json_decode($curl_response, true);*/

//print_r($json['status']);

if ($json['status'] == 'success') {

    //if sms is send success then insert lunch box count into the log table
    //to maintain lunch box history.
$daily_tiffen_count = $today_tiffen_count + $num_of_rows_for_nlb_fast + $eggitrains;


    $sql = "INSERT INTO `crc_lunchbox_log` (`_ID`, `lunchbox_date`, `veg_lunchbox_count`, `fast_lunchbox_count`, `non_veg_lunchbox_count`, `total_lunchbox_count`,`company_id`) VALUES (NULL,'$today',$today_tiffen_count,$num_of_rows_for_nlb_fast,$eggitrains,$daily_tiffen_count,$comapany_id)";

    if (mysqli_query($link, $sql)) {
        echo "New record created successfully";
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($link);
    }
}

// Close connection
mysqli_close($link);
