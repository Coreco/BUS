<?php



 
function sendSMS($message, $contactNo) {
	
	// Account details
	$username = 'rahul4nov@gmail.com	';
	$hash = '231b926f36dd8848ec461c6b1e2f8db61d06123a';
	
	// Message details
	//echo $message."--".$contactNo;
	
	$numbers = array ();
	$numbers [0] = $contactNo;
	$sender = urlencode ( 'CRCTEC' );
	
	$numbers = implode ( ',', $numbers );
	
	
	$message = rawurlencode ( $message );
	
	
	
	// Prepare data for POST request
	$data = array (
			'username' => $username,
			'hash' => $hash,
			'numbers' => $numbers,
			"sender" => $sender,
			"message" => $message 
	);
	
	// Send the POST request with cURL
	$ch = curl_init ( 'http://api.textlocal.in/send/' );
	curl_setopt ( $ch, CURLOPT_POST, true );
	curl_setopt ( $ch, CURLOPT_POSTFIELDS, $data );
	curl_setopt ( $ch, CURLOPT_RETURNTRANSFER, true );
	$response = curl_exec ( $ch );
	
	
	//echo $response;
	curl_close ( $ch );
}

?>