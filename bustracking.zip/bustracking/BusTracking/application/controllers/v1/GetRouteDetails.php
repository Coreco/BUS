<?php

defined('BASEPATH') OR exit('No direct script access allowed');

// This can be removed if you use __autoload() in config.php OR use Modular Extensions
/** @noinspection PhpIncludeInspection */
require APPPATH . 'libraries/REST_Controller.php';

/**
 * This is an example of a few basic user interaction methods you could use
 * all done with a hardcoded array
 *
 * @package         CodeIgniter
 * @subpackage      Rest Server
 * @category        Controller
 * @author          Phil Sturgeon, Chris Kacerguis
 * @license         MIT
 * @link            https://github.com/chriskacerguis/codeigniter-restserver
 */
class GetRouteDetails extends REST_Controller {

    function __construct()
    {
        // Construct the parent class
        parent::__construct();
        
       // error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));
        $this->load->model('Route_Model');
    }
    public function index_post()
    {

    }


    public function index_get()

    {

        /*
         Below API is to getting details of Route on bootstrapping 
         This Route details will save on locally 
        */

        $Bus_Route_List_array = array();
        $Bus_Route_details = $this->Route_Model->get_bus_route_details();	
        $Bus_Route_List_array = array('Route_list' =>$Bus_Route_details);

		print_r(json_encode($Bus_Route_List_array));

       

    }
    

}