<?php

defined('BASEPATH') OR exit('No direct script access allowed');

// This can be removed if you use __autoload() in config.php OR use Modular Extensions
/** @noinspection PhpIncludeInspection */
require APPPATH . 'libraries/REST_Controller.php';

/**
 * This is an example of a few basic user interaction methods you could use
 * all done with a hardcoded array
 *
 * @package         CodeIgniter
 * @subpackage      Rest Server
 * @category        Controller
 * @author          Phil Sturgeon, Chris Kacerguis
 * @license         MIT
 * @link            https://github.com/chriskacerguis/codeigniter-restserver
 */
class Test extends REST_Controller {

    function __construct()
    {
        // Construct the parent class
        parent::__construct();
        
       // error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));
        $this->load->model('Route_Model');
    }
    public function index_post()
    {

        echo "this is in post method";
    }


    public function index_get()

    {

        echo "this is in get method";

       

    }
    

}