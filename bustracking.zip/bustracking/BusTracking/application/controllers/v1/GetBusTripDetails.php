<?php

defined('BASEPATH') OR exit('No direct script access allowed');

// This can be removed if you use __autoload() in config.php OR use Modular Extensions
/** @noinspection PhpIncludeInspection */
require APPPATH . 'libraries/REST_Controller.php';

/**
 * This is an example of a few basic user interaction methods you could use
 * all done with a hardcoded array
 *
 * @package         CodeIgniter
 * @subpackage      Rest Server
 * @category        Controller
 * @author          Phil Sturgeon, Chris Kacerguis
 * @license         MIT
 * @link            https://github.com/chriskacerguis/codeigniter-restserver
 */
class GetBusTripDetails extends REST_Controller {

    function __construct()
    {
        // Construct the parent class
        parent::__construct();
        
       // error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));
        $this->load->model('Bus_Track_Model');
    }
    public function index_post()
    {



        $response_array = array();
		$bus_route_id = $_POST['bus_route_id'];
		

		$response = $this->Bus_Track_Model->GetBusTripDetails($bus_route_id);
        $seat_details_array = array('seat_details_array' =>$response);
		print_r(json_encode($seat_details_array));



    }


    
    

}