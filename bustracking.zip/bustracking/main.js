(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./src/$$_lazy_route_resource lazy recursive":
/*!**********************************************************!*\
  !*** ./src/$$_lazy_route_resource lazy namespace object ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(function() {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = function() { return []; };
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
module.exports = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = "./src/$$_lazy_route_resource lazy recursive";

/***/ }),

/***/ "./src/app/app.component.css":
/*!***********************************!*\
  !*** ./src/app/app.component.css ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "agm-map{\r\n    height:500px;\r\n    zoom: 1;\r\n}\r\n.angular-google-map-container {\r\n    height: 400px;\r\n    margin-bottom: 15px;\r\n  }\r\n.panel-primary {\r\n    padding: 15px;\r\n  }"

/***/ }),

/***/ "./src/app/app.component.html":
/*!************************************!*\
  !*** ./src/app/app.component.html ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class='container'>\n  <div class='row'>\n    <div class='col-md-6'>\n      <button class=\"btn-primary btn-block\">By Bus</button>\n    </div>\n    <div class='col-md-6'>\n      <button class=\"btn-primary btn-block\">By Route</button>\n    </div>\n  </div><br><br><br>\n  <div class=\"row\">\n    <div class=\"col-md-4\">\n\n    </div>\n    <div class=\"col-md-4\">\n      <form  #Search=\"ngForm\" (submit)=\"onSearch()\">\n        <div class=\"form-row\">\n            <div class=\"form-group\">\n                 Select Bus: <select name=\"busid\" [(ngModel)]=\"busid\">\n                    <option  select=\"selected\" disabled>Select Bus</option>\n                    <option value=\"1\">1</option>\n                    <option value=\"2\">2</option>\n                    <option value=\"4\">3</option>\n                  </select>\n            </div>\n        </div>\n        <div class=\"form-row\">\n            <div class=\"form-group\">\n                <button class=\"btn btn-primary btn-block\" type=\"submit\">Select Bus</button>\n              </div>\n        </div>\n      </form>\n    </div>\n  </div>\n  <div class='row'>\n    <div class=\"col-md-8\">\n        <agm-map [latitude]=\"lati\" [longitude]=\"lngi\">\n            \n            <agm-marker id='strloc'[latitude]=\"str_loc_lat\" [longitude]=\"str_loc_lon\"></agm-marker>\n            <agm-marker id='strloc'[latitude]=\"lat\" [longitude]=\"lng\"></agm-marker>\n            <agm-marker id='strloc'[latitude]=\"end_loc_lat\" [longitude]=\"end_loc_lon\">End</agm-marker>\n        </agm-map>\n    </div>\n    <div class=\"col-md-4\">\n        <!--<div class=\"progress blue\">\n            <span class=\"progress-left\">\n                <span class=\"progress-bar\"></span>\n            </span>\n            <span class=\"progress-right\">\n                <span class=\"progress-bar\"></span>\n            </span>\n            <div class=\"progress-value\">90%</div>\n        </div><br>-->\n        <h3>Available Seats:-{{availseats}}</h3>\n        <strong>Started At:-</strong>{{strtime}}<br>\n        <strong>Last Known Location:-</strong>{{lat}},{{lng}}<br>\n        <strong>Last Known Time:-</strong>{{curloc}}<br>\n        <strong>ETA:-</strong>{{eta}}\n    </div>\n  </div>\n</div> \n\n<!-- <input type=\"button\" id=\"routebtn\" value=\"route\" />\n<div id=\"map-canvas\"></div> -->"

/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _langlat_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./langlat.service */ "./src/app/langlat.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var AppComponent = /** @class */ (function () {
    function AppComponent(langlatser) {
        this.langlatser = langlatser;
        this.title = 'googlemap';
        this.lati = 19.07283;
        this.lngi = 72.88261;
    }
    AppComponent.prototype.ngOnInit = function () {
    };
    AppComponent.prototype.onSearch = function () {
        var _this = this;
        console.log("in on search");
        this.langlatser.getDataByBus(this.busid).subscribe(function (data) {
            if (data != null) {
                _this.lat = data[0].bus_last_known_location_latitude;
                console.log(_this.lat);
                _this.lng = data[0].bus_last_known_location_longitude;
                console.log(_this.lng);
                _this.strtime = data[0].bus_trip_start_date_time;
                _this.eta = data[0].bus_eta_end_location;
                _this.availseats = data[0].bus_available_seats;
                _this.str_loc_lon = data[0].route_start_geo_location_longitude;
                _this.str_loc_lat = data[0].route_end_geo_location_latitude;
                _this.end_loc_lat = data[0].route_end_geo_location_latitude;
                _this.end_loc_lon = data[0].route_end_geo_location_longitude;
                _this.curloc = data[0].bus_trip_start_date_time;
                _this.getLocation(_this.lat, _this.lng, _this.end_loc_lat, _this.end_loc_lon);
            }
        });
    };
    AppComponent.prototype.getLocation = function (clat, clng, dlat, dlng) {
        console.log('in getlocation method');
        var data = [{ clat: clat,
                clng: clng,
                dlat: dlat,
                dlng: dlng }];
        this.langlatser.getLocation(data).subscribe(function (data) {
            console.log(data);
        });
    };
    AppComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-root',
            template: __webpack_require__(/*! ./app.component.html */ "./src/app/app.component.html"),
            styles: [__webpack_require__(/*! ./app.component.css */ "./src/app/app.component.css")]
        }),
        __metadata("design:paramtypes", [_langlat_service__WEBPACK_IMPORTED_MODULE_1__["LanglatService"]])
    ], AppComponent);
    return AppComponent;
}());



/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm5/platform-browser.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _agm_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @agm/core */ "./node_modules/@agm/core/index.js");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _langlat_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./langlat.service */ "./src/app/langlat.service.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};







var AppModule = /** @class */ (function () {
    function AppModule() {
    }
    AppModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            declarations: [
                _app_component__WEBPACK_IMPORTED_MODULE_3__["AppComponent"]
            ],
            imports: [
                _angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__["BrowserModule"],
                _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpClientModule"],
                _agm_core__WEBPACK_IMPORTED_MODULE_2__["AgmCoreModule"].forRoot({
                    apiKey: 'AIzaSyDGDCRB1LgAf6tAilQmU0BDoRWFd7uWcjc'
                }),
                _angular_forms__WEBPACK_IMPORTED_MODULE_6__["FormsModule"]
            ],
            providers: [_langlat_service__WEBPACK_IMPORTED_MODULE_5__["LanglatService"]],
            bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_3__["AppComponent"]]
        })
    ], AppModule);
    return AppModule;
}());



/***/ }),

/***/ "./src/app/langlat.service.ts":
/*!************************************!*\
  !*** ./src/app/langlat.service.ts ***!
  \************************************/
/*! exports provided: LanglatService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LanglatService", function() { return LanglatService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var LanglatService = /** @class */ (function () {
    function LanglatService(http) {
        this.http = http;
    }
    LanglatService.prototype.getData = function () {
        return this.http.get('');
    };
    LanglatService.prototype.getDataByBus = function (id) {
        var data = [{ busid: id }];
        console.log('in service');
        return this.http.post('http://ec2-52-66-86-76.ap-south-1.compute.amazonaws.com/BUS/BusTracking/index.php/v1/GetBusTripDetails', data);
    };
    LanglatService.prototype.getLocation = function (data) {
        /*const headers = new HttpHeaders()
      .append('Access-Control-Expose-Headers', 'Access-Control-*, Origin, X-Requested-With, Content-Type, Accept, Authorization')
       .append('Access-Control-Allow-Origin', 'http://localhost:4200')
       .append('Access-Control-Allow-Methods', 'HEAD, GET, POST, OPTIONS, PUT, PATCH, DELETE')
       .append('Access-Control-Allow-Headers', 'Access-Control-*, Origin, X-Requested-With, Content-Type, Accept, Authorization');
       //.append('Access-Control-Allow-Credentials', true);
         .append('Content-Type', 'application/x-www-form-urlencoded')
         .append('Access-Control-Allow-Headers', 'Content-Type')
         .append('Access-Control-Allow-Methods', 'GET')
         .append('Access-Control-Allow-Origin', '*');*/
        console.log('in service');
        //return this.http.get(`https://maps.googleapis.com/maps/api/distancematrix/json?units=imperial&origins=${clat},${clng}&destinations=${dlat}%2C${dlng}&key=AIzaSyDGDCRB1LgAf6tAilQmU0BDoRWFd7uWcjc`);
        //return this.http.get(`https://corecotechnologies.com/BusTracking/index.php/v1/Test`,{headers});
        return this.http.post('http://localhost:8081/getAddress', data);
    };
    LanglatService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"]])
    ], LanglatService);
    return LanglatService;
}());



/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build ---prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
var environment = {
    production: false
};
/*
 * In development mode, for easier debugging, you can ignore zone related error
 * stack frames such as `zone.run`/`zoneDelegate.invokeTask` by importing the
 * below file. Don't forget to comment it out in production mode
 * because it will have a performance impact when errors are thrown
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "./node_modules/@angular/platform-browser-dynamic/fesm5/platform-browser-dynamic.js");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");




if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])
    .catch(function (err) { return console.log(err); });


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! C:\Users\Om\Desktop\Nodejs\Angular\googlemap\src\main.ts */"./src/main.ts");


/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main.js.map